create function interval_pl_date(interval, date) returns timestamp without time zone
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function interval_pl_date(interval, date) is 'implementation of + operator';

alter function interval_pl_date(interval, date) owner to postgres;

